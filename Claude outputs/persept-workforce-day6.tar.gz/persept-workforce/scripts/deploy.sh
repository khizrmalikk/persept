#!/usr/bin/env bash
# deploy.sh — push this repo's agents into the running OpenClaw instance on this host.
#
#   ./scripts/deploy.sh            deploy every enabled agent in client.yaml
#   ./scripts/deploy.sh chief      deploy one agent
#
# What it does, per agent: render templates -> ~/.openclaw/workspace-<id>/, apply
# config/<id>.json as agents.entries.<id>, run automations/<id>.sh, then restart the gateway.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMPOSE_FILE="${OPENCLAW_COMPOSE:-/srv/openclaw-upstream/docker-compose.yml}"
STATE_DIR="${OPENCLAW_STATE:-$HOME/.openclaw}"
export OC="docker compose -f $COMPOSE_FILE"

command -v python3 >/dev/null || { echo "python3 required"; exit 1; }
python3 -c "import yaml" 2>/dev/null || sudo apt-get install -y python3-yaml

export TZ="$(python3 -c "import yaml;print(yaml.safe_load(open('$ROOT/client.yaml'))['client']['timezone'])")"
export MODEL_ROUTINE="$(python3 -c "import yaml;print(yaml.safe_load(open('$ROOT/client.yaml'))['models']['routine'])")"
export MODEL_CHEAP="$(python3 -c "import yaml;print(yaml.safe_load(open('$ROOT/client.yaml'))['models']['cheap'])")"
export MODEL_DEFAULT="$(python3 -c "import yaml;print(yaml.safe_load(open('$ROOT/client.yaml'))['models']['default'])")"
export OWNER_CHAT="$(python3 -c "import yaml;print(yaml.safe_load(open('$ROOT/client.yaml'))['channels']['telegram']['owner_chat_id'])")"

if [ $# -gt 0 ]; then
  AGENTS="$*"
else
  AGENTS="$(python3 -c "import yaml;print(' '.join(a['id'] for a in yaml.safe_load(open('$ROOT/client.yaml'))['roster'] if a.get('enabled')))")"
fi

echo "==> cost guard: default model $MODEL_DEFAULT, heartbeat off"
$OC run --rm openclaw-cli config set agents.defaults.model "\"$MODEL_DEFAULT\""
$OC run --rm openclaw-cli config set agents.defaults.heartbeat.every '"0m"'

# Secrets for the bridge and for per-agent provider auth live in $ROOT/.env (gitignored).
if [ -f "$ROOT/.env" ]; then set -a; . "$ROOT/.env"; set +a; fi
if [ -z "${OPENCLAW_GATEWAY_TOKEN:-}" ] && [ -f "$HOME/.openclaw-gateway-token" ]; then
  echo "OPENCLAW_GATEWAY_TOKEN=$(cat "$HOME/.openclaw-gateway-token")" >> "$ROOT/.env"
  export OPENCLAW_GATEWAY_TOKEN="$(cat "$HOME/.openclaw-gateway-token")"
fi

ensure_agent_auth() {
  # OpenClaw stores provider keys per agent; a new agent has none until one is pasted.
  local id="$1"
  [ -n "${ANTHROPIC_API_KEY:-}" ] || { echo "   (no ANTHROPIC_API_KEY in .env; paste one manually if $id fails with missing-provider-auth)"; return 0; }
  if printf '%s\n' "$ANTHROPIC_API_KEY" | $OC run --rm -T openclaw-cli models auth paste-api-key --provider anthropic --agent "$id" >/dev/null 2>&1; then
    echo "   provider auth set for $id"
  else
    echo "   could not set provider auth for $id non-interactively; run: oc run --rm -it openclaw-cli models auth paste-api-key --provider anthropic --agent $id"
  fi
}

for id in $AGENTS; do
  echo "==> $id"
  python3 "$ROOT/scripts/render.py" "$id" "$STATE_DIR/workspace-$id"
  if [ -f "$ROOT/.rendered/$id.json" ]; then
    $OC run --rm openclaw-cli config set "agents.entries.$id" "$(cat "$ROOT/.rendered/$id.json")"
    echo "   applied agents.entries.$id"
  fi
  ensure_agent_auth "$id"
  if [ -x "$ROOT/automations/$id.sh" ]; then
    "$ROOT/automations/$id.sh"
  fi
done

echo "==> restarting gateway"
$OC restart openclaw-gateway
sleep 10
$OC exec openclaw-gateway sh -lc 'node dist/index.js gateway health --token "$OPENCLAW_GATEWAY_TOKEN"' || true

# Bridge: only when Supabase credentials exist in .env
if [ -n "${SUPABASE_URL:-}" ] && [ -n "${SUPABASE_SERVICE_KEY:-}" ]; then
  echo "==> bridge"
  $OC -f "$ROOT/bridge/docker-compose.override.yml" build bridge && $OC -f "$ROOT/bridge/docker-compose.override.yml" up -d --no-deps bridge
  sleep 4
  $OC -f "$ROOT/bridge/docker-compose.override.yml" logs --tail=15 bridge || true
else
  echo "==> bridge skipped (no SUPABASE_URL / SUPABASE_SERVICE_KEY in .env)"
fi
echo "done"
