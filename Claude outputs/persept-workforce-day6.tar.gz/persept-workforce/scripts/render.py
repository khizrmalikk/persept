#!/usr/bin/env python3
"""Render agent workspace templates from client.yaml into a target directory.

Usage: render.py <agent_id> <target_dir>

Substitutes {{client.*}}, {{models.*}}, {{roster}} and {{guardrails}} in every *.md and
*.json under agents/<agent_id>/ and config/<agent_id>.json. Never overwrites MEMORY.md or
anything under memory/ in the target, because the agent owns those once it is running.
"""
import json, os, re, shutil, sys

try:
    import yaml  # python3-yaml
except ImportError:
    sys.exit("python3-yaml missing: sudo apt-get install -y python3-yaml")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
agent, target = sys.argv[1], sys.argv[2]
cfg = yaml.safe_load(open(os.path.join(ROOT, "client.yaml")))

def flat(d, prefix=""):
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flat(v, key + "."))
        else:
            out[key] = "" if v is None else str(v)
    return out

subs = flat({"client": cfg["client"], "models": cfg.get("models", {})})
roster_lines = []
for a in cfg.get("roster", []):
    state = "enabled" if a.get("enabled") else "not enabled yet"
    roster_lines.append(f"- {a['id']}: {a['role']} ({state})")
subs["roster"] = "\n".join(roster_lines)
shared = os.path.join(ROOT, "agents", "_shared")
subs["guardrails"] = "\n\n".join(
    open(os.path.join(shared, f)).read().strip() for f in ("GUARDRAILS.md", "HOUSE_STYLE.md")
)

def render(text):
    return re.sub(r"\{\{([a-zA-Z0-9_.]+)\}\}", lambda m: subs.get(m.group(1), m.group(0)), text)

src = os.path.join(ROOT, "agents", agent)
if not os.path.isdir(src):
    sys.exit(f"no agents/{agent} folder")
os.makedirs(os.path.join(target, "memory"), exist_ok=True)

for name in os.listdir(src):
    p = os.path.join(src, name)
    if os.path.isdir(p):
        continue
    dest = os.path.join(target, name)
    if name == "MEMORY.md" and os.path.exists(dest):
        continue  # agent-owned once live
    with open(p) as f:
        content = render(f.read())
    with open(dest, "w") as f:
        f.write(content)
    print(f"   wrote {dest}")

# Rendered config entry, to be applied by deploy.sh
conf_src = os.path.join(ROOT, "config", f"{agent}.json")
if os.path.exists(conf_src):
    rendered = render(open(conf_src).read())
    json.loads(rendered)  # fail early if the JSON is broken
    out = os.path.join(ROOT, ".rendered")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, f"{agent}.json"), "w") as f:
        f.write(rendered)
    print(f"   rendered config for {agent}")
