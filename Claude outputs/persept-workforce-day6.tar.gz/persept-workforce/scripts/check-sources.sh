#!/usr/bin/env bash
# check-sources.sh — probe every feed URL in agents/scout/SOURCES.md and report status + size.
# Run on the VPS before deploying Scout, and whenever the digest reports "sources down".
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
UA="Mozilla/5.0 (X11; Linux x86_64) PerseptScout/0.1"
printf "%-8s %-9s %s\n" "STATUS" "BYTES" "SOURCE"
grep -E '^- .* \| https?://' "$ROOT/agents/scout/SOURCES.md" | while IFS='|' read -r name url why; do
  name="$(echo "$name" | sed 's/^- *//;s/ *$//')"; url="$(echo "$url" | xargs)"
  out="$(curl -sS -L -A "$UA" --max-time 20 -o /tmp/feed.$$ -w "%{http_code}" "$url" 2>/dev/null || echo "ERR")"
  bytes="$(stat -c %s /tmp/feed.$$ 2>/dev/null || echo 0)"
  items="$(grep -c -E '<item>|<entry>' /tmp/feed.$$ 2>/dev/null || echo 0)"
  printf "%-8s %-9s %s  (%s items)\n" "$out" "$bytes" "$name" "$items"
done
rm -f /tmp/feed.$$
echo
echo "Anything not 200 with 0 items: fix the URL in SOURCES.md or remove the line."
