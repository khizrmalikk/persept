#!/usr/bin/env bash
# Scheduled jobs for the Chief of Staff. Idempotent: skips a job whose name already exists.
# Usage: automations/chief.sh   (called by scripts/deploy.sh; needs $OC, $TZ, $OWNER_CHAT)
set -euo pipefail
: "${OC:?OC (docker compose command) not set}"
: "${TZ:?TZ not set}"
: "${OWNER_CHAT:?OWNER_CHAT not set}"
: "${MODEL_ROUTINE:?MODEL_ROUTINE not set}"

have_job() { $OC run --rm openclaw-cli automations list 2>/dev/null | grep -q -- "$1"; }

if have_job "chief-morning-brief"; then
  echo "   job chief-morning-brief exists, leaving it (delete it with: $OC run --rm openclaw-cli automations delete <id>)"
else
  $OC run --rm openclaw-cli automations create "0 8 * * *" \
    --name "chief-morning-brief" \
    --tz "$TZ" \
    --agent chief \
    --session isolated \
    --model "$MODEL_ROUTINE" \
    --tools read,write \
    --message "It is 08:00. Produce today's morning brief in exactly the format given in AGENTS.md. Read memory/ for yesterday's log and MEMORY.md for standing items. If a section has nothing, write 'nothing'. Output only the brief." \
    --announce --channel telegram --to "$OWNER_CHAT"
  echo "   created job chief-morning-brief (08:00 $TZ, $MODEL_ROUTINE -> telegram $OWNER_CHAT)"
fi
