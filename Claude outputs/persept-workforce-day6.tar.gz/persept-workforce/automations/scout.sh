#!/usr/bin/env bash
# Scheduled jobs for Scout. Idempotent: skips a job whose name already exists.
set -euo pipefail
: "${OC:?OC not set}"; : "${TZ:?TZ not set}"; : "${OWNER_CHAT:?OWNER_CHAT not set}"; : "${MODEL_CHEAP:?MODEL_CHEAP not set}"

have_job() { $OC run --rm openclaw-cli automations list 2>/dev/null | grep -q -- "$1"; }

if have_job "scout-daily-digest"; then
  echo "   job scout-daily-digest exists, leaving it"
else
  $OC run --rm openclaw-cli automations create "0 6 * * *" \
    --name "scout-daily-digest" \
    --tz "$TZ" \
    --agent scout \
    --session isolated \
    --model "$MODEL_CHEAP" \
    --tools read,write,web_fetch \
    --message "It is 06:00. Run the daily digest exactly as described in AGENTS.md: read /home/node/.openclaw/workspace-scout/SOURCES.md, fetch each feed, drop anything in memory/seen.md, pick at most 8 items, write memory/digests/<today YYYY-MM-DD>.md and update memory/seen.md, then output only the digest." \
    --announce --channel telegram --to "$OWNER_CHAT"
  echo "   created job scout-daily-digest (06:00 $TZ, $MODEL_CHEAP -> telegram $OWNER_CHAT)"
fi
