#!/usr/bin/env bash
# Scheduled jobs for Hunter. Idempotent: skips a job whose name already exists.
# Runs in Hunter's MAIN session on purpose: the bridge reads main-session history, so every
# APPROVAL REQUEST from the daily run lands in the dashboard inbox.
set -euo pipefail
: "${OC:?OC not set}"; : "${TZ:?TZ not set}"; : "${OWNER_CHAT:?OWNER_CHAT not set}"; : "${MODEL_ROUTINE:?MODEL_ROUTINE not set}"

have_job() { $OC run --rm openclaw-cli automations list 2>/dev/null | grep -q -- "$1"; }

if have_job "hunter-daily-run"; then
  echo "   job hunter-daily-run exists, leaving it"
else
  $OC run --rm openclaw-cli automations create "0 9 * * 0-4" \
    --name "hunter-daily-run" \
    --tz "$TZ" \
    --agent hunter \
    --session main \
    --model "$MODEL_ROUTINE" \
    --tools read,write,edit,web_fetch \
    --message "It is 09:00. Run the daily run exactly as described in AGENTS.md: read PROSPECTS.md, do follow-ups due first, then up to 5 new first touches, one APPROVAL REQUEST per message in the required format, update PROSPECTS.md to drafted, log the run. If nothing is due, say so in one line." \
    --announce --channel telegram --to "$OWNER_CHAT"
  echo "   created job hunter-daily-run (09:00 $TZ Sun-Thu, $MODEL_ROUTINE, main session -> telegram $OWNER_CHAT)"
fi
