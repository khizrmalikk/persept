# Standing memory (curated; keep under 40 lines)

- Workforce started 14 Sep 2026 on a fresh instance. Chief is the first agent live.
- Roster planned: scout, hunter, fixer, muse, scribe. Enabled one at a time.
- Owner's key metric for the next two weeks: discovery calls booked.
