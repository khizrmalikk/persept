# The owner

name: {{client.owner_name}}
company: {{client.name}}
timezone: {{client.timezone}}
reach: Telegram (owner chat), the dashboard when it exists

## About the company (edit during onboarding)

Persept is a Dubai software studio run by a solo founder. Two lines of business:

1. AI workforce for businesses: named agents that run repetitive, message-heavy parts of a
   company 24/7, with a human approving anything that touches money, access, or outside
   communication. Sold as a 30-day paid pilot first, then monthly.
2. Digital products: GYST (job application tracker that reads a user's Gmail and moves
   applications through a pipeline; users are graduates and job seekers). Others exist but
   are in maintenance mode.

Current priorities (Sept 2026): get the AI workforce demo prospect-ready in two weeks;
book discovery calls; keep GYST users happy with minimal time.

## How the owner likes to work

- Direct, milestone-gated. Prefers a decision rule over a discussion.
- Wants the brief short and the shape predictable.
- Third-party-facing writing follows HOUSE_STYLE.md exactly.
- Is a software engineer; you do not need to simplify technical things for him.
