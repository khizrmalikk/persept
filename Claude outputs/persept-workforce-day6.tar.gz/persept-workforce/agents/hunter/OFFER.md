# The offer (edit this per client during onboarding)

## What {{client.name}} sells, in the buyer's words

An AI workforce for a business: named agents that run the repetitive, message-heavy parts of a
company 24/7 inside the tools the business already uses, with a human approving anything that
involves money, access or a customer. Not a chatbot. Not autopilot. A team that drafts and
prepares, where the owner presses send.

What it takes over, by function: outbound and inbound sales follow-up; guest or customer
messaging; scheduling and dispatch of field staff or vendors; feedback and support triage;
proposals and documents from a template; owner reporting and daily briefs.

## Proof we can use (only these)

- {{client.name}} runs on its own workforce: a Chief of Staff brief every morning, a market
  digest every day, outreach drafted by an agent, all approved by one person from a dashboard.
- The founder built and runs the whole stack himself, on infrastructure the client owns
  (one isolated deployment per client, nothing shared).
- Vertical example, property hospitality: guest questions answered in under two minutes 24/7,
  cleaners chased until they confirm, owner statements on the 1st; plugs into Hostaway and
  Guesty, so no migration.
- Do not quote client names, response-time results or hours saved until a pilot has produced them.

## Pricing and the ask

- The ask is always a 15-minute call, never a sale.
- Engagement: AED 6,000 for a 30-day paid pilot (setup, integration, playbooks, a month live),
  then AED 2,500 a month. Founder rate for the first three in exchange for a case study.
- Anchor if price comes up: one ops or guest-experience hire is AED 5,000 to 8,000 a month plus
  visa and works 8 hours; the workforce costs less than that and works 24/7.
- Never offer a discount in writing. Say the founder will discuss terms on the call.

## Objections (answer in one or two lines, then return to the ask)

- "we tried a chatbot, customers hated it": this is not a menu bot. it reads the real context
  (the booking, the ticket, the thread) and writes like your best coordinator; anything it is
  unsure about goes to your team, so nobody hits a dead end
- "what about refunds, door codes, payments": never autonomous. money, access and disputes
  always go to a human with one-tap approval. we lead with this
- "data privacy": every client runs on its own isolated deployment; your data stays in your
  instance; UAE PDPL-aligned; a simple DPA is included
- "we are too small": the pilot is priced under half of one salary
- "we are too big": start with one building, one channel or one team as the pilot and measure

## Availability windows for calls ({{client.timezone}})

Sunday to Thursday, 10:00 to 12:30 and 15:00 to 17:30. Propose three slots at least 24 hours
out, never two on the same day. The owner confirms on the call; Hunter never books directly.

## Links

- 60-second demo video: (add link when recorded)
- Site: https://persept.ai
