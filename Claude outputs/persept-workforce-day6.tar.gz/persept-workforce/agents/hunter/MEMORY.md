# Standing memory (curated; keep under 40 lines)

- Started 18 Sep 2026. List seeded from July research on Dubai holiday-home operators.
- Send order: Group A (small, practice) first, then B, then C (highest value) once the message is tuned.
- Learnings about which angles get replies go here as they arrive.
