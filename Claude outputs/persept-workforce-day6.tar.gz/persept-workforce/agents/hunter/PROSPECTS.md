# Prospects

Status values: new | drafted | approached | followed_up_1 | followed_up_2 | replied | call_booked | parked | no
Priority: 1 = verified fit and contact, 2 = good fit, contact partial, 3 = large or verify-first.
Dates are YYYY-MM-DD. `next_due` blank means nothing scheduled. Keep one row per company.

Seeded 18 Sep 2026 from the July research (Dubai holiday-home operators; Hostaway/Guesty users
verified via their booking-site domains). Contacts were public in July; treat as unverified
until a reply proves them. Add prospects from any industry below; the offer is horizontal.

| priority | company | contact | channel | address | units_or_size | angle | status | last_touch | next_due | notes |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | La Brisa Dubai | owner (unnamed) | email | labrisadubai@gmail.com | ~19 units | expanding into Downtown and Dubai Hills; inbox grows faster than the team | new | | 2026-09-18 | Group A practice rep |
| 1 | Savis Vacation Homes | family owners (unnamed) | email | holidays@savisrealty.com | ~24 units | Vancouver family, new to Dubai, split timezones, 24/7 cover | new | | 2026-09-18 | Group A |
| 1 | Elegant Homes UAE | ops (unnamed) | whatsapp | +971 56 354 3535 | ~39 units | their whole site funnels to WhatsApp; pitch is that channel, automated | new | | 2026-09-18 | Group A |
| 1 | Sunrise Vacation Homes | Teuta / Hamza (hosts named in reviews) | instagram | @sunrisevacationhomes, then info@sunrisevacationhomes.ae | ~40 listings | reviews praise their response speed; that speed does not scale at +48% growth | new | | 2026-09-18 | Group A |
| 1 | New Homer Holiday Homes | Emre Elibol (CEO), Sinan Hanoglu (COO) | whatsapp | +971 55 142 8284 | ? | Dubai, Italy and Bali: three timezones of guest messages | new | | 2026-09-19 | Group B; site is Turkish |
| 1 | Nest N Rest Holiday Homes | Ahmed Elrouby (BD) | email | nestrest078@gmail.com | ? | growth push across Dubai and Abu Dhabi; every new owner adds 60 to 120 messages a month | new | | 2026-09-19 | Group B |
| 1 | Dubai Vacation Homes | owner (English-owned, 20+ yrs) | email | via dvh.holidayfuture.com contact | ? | twenty years in; the 2am messages have not improved in twenty years | new | | 2026-09-19 | Group B |
| 1 | Durrani Holiday Homes | Mohammad Suhadh (Ops Manager) | whatsapp | +971 58 108 2601 | ~25 staff | Downtown review volume = message volume; their job ads already pay for channel-manager skills | new | | 2026-09-19 | Group B; reservation@durranihomes.com backup |
| 1 | Medini Holiday Homes | Hillal Medini (founder, ex-hotelier) | linkedin | linkedin.com/in/hillal-medini | ~114 units | raise the standard of his in-house team, not replace it | new | | 2026-09-20 | Group B |
| 1 | CzechIn Holiday Homes | Jiri Chlebek (founder, CEO) | linkedin | linkedin.com/in/jiri-chlebek | ~31 units | speaking at REALFEST Nov 2026; owner reporting for Czech/Slovak investors is the wedge | new | | 2026-09-21 | Group C |
| 1 | Vogue Vacation Homes | Wael Baidas (MD) | linkedin | linkedin.com/in/wael-baidas | ~176 units | 94.6% occupancy claim = maximum message volume; audit log matters to a corporate JV | new | | 2026-09-21 | Group C |
| 1 | LUX Holiday Home | Abbas Nasser (CEO), via guest line | whatsapp | +971 52 521 5626 | ~150 listings, 35+ staff | already paying reservations and guest-relations salaries; payroll anchor | new | | 2026-09-21 | Group C; bookings@luxholidayhome.com day-7 |
| 1 | Vacationer Dubai | Harrison Moore (CEO) | linkedin | linkedin.com/in/harrison-moore | ~320 listings | his Hostaway case study is about centralising ops; we are the next chapter | new | | 2026-09-22 | Group C; warmest lead; may refer to Head of Ops |
| 2 | Mai De Luxe | Alexandra Kraft (co-founder) | linkedin | | boutique | founder-led boutique; personal service at scale | new | | | PMS unknown |
| 2 | Daniels Holiday Homes | | email | | ~50 units | sweet-spot size | new | | | contact needed |
| 2 | Elite LUX | | email | | ~36 units | Marriott partner; standards | new | | | contact needed |
| 2 | Vacay Lettings | | email | | ~74 units | est. 2008; longevity angle | new | | | contact needed |
| 2 | Maison Privée | | linkedin | | ~100 units | Series A, awards; scale story | new | | | contact needed |
| 2 | First Class Property Management | Rohollah Rohparwar, Luis Santos (co-founders, ex-engineers) | linkedin | | ~400 units | data-driven engineering founders; strong AI-ops fit | new | | | Group C candidate once contact found |
| 2 | StoneTree | Alexey Shchevlyagin (CEO) | linkedin | | | | new | | | contact needed |
| 3 | GuestReady | Burhan Hayat (Dubai head) | linkedin | | 600+ | mega-operator; pilot one building | new | | | later |
| 3 | Frank Porter | | | | 650+ | mega-operator | new | | | later |
