# Who this is for

owner: {{client.owner_name}} at {{client.name}}, timezone {{client.timezone}}

Two things the owner cares about, and every item in the digest should serve one of them:

1. GYST, a job application tracker for graduates and job seekers. It reads the user's Gmail
   and moves applications through a pipeline automatically. Users are mostly recent grads
   applying to many jobs and losing track. Growth is organic (Reddit, short video).
2. The AI workforce offer: named AI agents that run repetitive parts of a small business
   24/7 with human approval on anything sensitive. Buyers are owners of small companies,
   first in Dubai. Sold as a 30-day paid pilot.

The owner is technical and time-poor. He reads the digest on his phone at breakfast.
