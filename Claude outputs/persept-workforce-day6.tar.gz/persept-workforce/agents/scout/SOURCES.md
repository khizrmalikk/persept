# Sources (edit freely; Scout reads this file every run)

Each line: <name> | <url> | <why it is here>. Feeds are RSS/Atom/JSON so no search plugin
is needed. Keep to about 12 sources; more than that costs tokens without adding signal.

## GYST: job seekers, graduates, application tracking
- r/jobs top today | https://www.reddit.com/r/jobs/top/.rss?t=day | what job seekers are angry about this week
- r/cscareerquestions top | https://www.reddit.com/r/cscareerquestions/top/.rss?t=day | grads in tech, our core GYST user
- r/GetEmployed top | https://www.reddit.com/r/GetEmployed/top/.rss?t=day | practical job-hunt pain points
- r/recruitinghell top | https://www.reddit.com/r/recruitinghell/top/.rss?t=day | ghosting, ATS, tracking chaos; content gold
- Google News: graduate job market | https://news.google.com/rss/search?q=%22graduate+job+market%22+OR+%22entry+level+jobs%22&hl=en-US&gl=US&ceid=US:en | macro trend stats for content
- Google News: job application tracker | https://news.google.com/rss/search?q=%22job+application+tracker%22+OR+%22job+search+app%22&hl=en-US&gl=US&ceid=US:en | competitor launches and coverage

## AI workforce offer: agents for small businesses, UAE
- Google News: AI agents small business | https://news.google.com/rss/search?q=%22AI+agents%22+%22small+business%22&hl=en-US&gl=US&ceid=US:en | buyer-side narrative and objections
- Google News: AI UAE business | https://news.google.com/rss/search?q=%22AI%22+UAE+business+automation&hl=en-AE&gl=AE&ceid=AE:en | local market, regulation, competitors
- Product Hunt: AI | https://www.producthunt.com/feed?category=artificial-intelligence | new agent products and positioning
- OpenClaw releases | https://github.com/openclaw/openclaw/releases.atom | our platform; breaking changes and new channels
- Hacker News: AI agents | https://hnrss.org/newest?q=%22AI+agents%22&points=50 | what technical buyers are debating

## Competitors to watch by name (add as you learn them)
- (none yet; add lines like: Name | feed or news URL | why)
