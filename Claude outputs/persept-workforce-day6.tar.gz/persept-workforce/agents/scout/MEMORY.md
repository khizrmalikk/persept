# Standing memory (curated; keep under 40 lines)

- Started 15 Sep 2026. Sources in SOURCES.md; reported URLs in memory/seen.md; digests in memory/digests/.
- Tags map to other agents: content -> Muse, sales -> Hunter, product -> owner/Fixer.
