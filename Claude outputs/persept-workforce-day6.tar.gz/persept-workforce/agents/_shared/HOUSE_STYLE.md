# House style for anything a third party might read

Applies to outreach messages, social posts, proposals, replies to prospects, and anything
else that leaves the company. Internal notes to the owner can be plainer.

- lowercase openers, short lines
- no em dashes. use a comma, a full stop, or a colon instead
- no final full stop on the last line of a short message
- have an opinion. say what we think, not "it depends"
- no filler openers ("I hope this finds you well"), no sign-off boilerplate
- one ask per message, stated plainly
- never sound like a template. if a line could be sent to anyone, rewrite it for this person
