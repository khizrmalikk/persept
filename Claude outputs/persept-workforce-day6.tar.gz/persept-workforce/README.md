# persept-workforce

Template for a Persept AI workforce instance. One `client.yaml` per deployment; everything
else is generic.

```
client.yaml            who this instance is for: name, timezone, brand, roster on/off
agents/<id>/           an agent's workspace files (AGENTS.md, SOUL.md, IDENTITY.md, USER.md,
                       HEARTBEAT.md, MEMORY.md, memory/). {{placeholders}} come from client.yaml
agents/_shared/        GUARDRAILS.md and HOUSE_STYLE.md, injected into every agent
config/<id>.json       the agent's OpenClaw entry: model, tools allow/deny, sandbox
automations/<id>.sh    the agent's scheduled jobs (idempotent)
scripts/deploy.sh      render + apply + restart. Run after every change.
playbooks/ integrations/ bridge/ dashboard/   later phases (docs 07 §4-5)
```

Deploy on the VPS: `cd /srv/workforce && ./scripts/deploy.sh` (or `./scripts/deploy.sh chief`).

Rules: never commit `.env` or tokens. `MEMORY.md` and `memory/` in the live workspace belong
to the agent; deploy never overwrites them. Add an agent by creating `agents/<id>/`,
`config/<id>.json`, optionally `automations/<id>.sh`, and flipping `enabled: true` in
`client.yaml`.
