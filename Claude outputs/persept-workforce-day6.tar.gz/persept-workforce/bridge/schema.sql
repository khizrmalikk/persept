-- Persept workforce bridge: Supabase schema v0
-- Run once in the Supabase SQL editor of a fresh project. Service-role key only for now;
-- row-level security is enabled with no anon policies, so nothing is readable without it.

create table if not exists instance (
  id text primary key,                 -- client id from client.yaml, e.g. 'persept'
  name text,
  gateway_version text,
  health jsonb,
  last_seen_at timestamptz,
  updated_at timestamptz default now()
);

create table if not exists agents (
  id text primary key,                 -- agent id, e.g. 'chief'
  name text,
  role text,
  emoji text,
  model text,
  status text default 'idle',          -- idle | working | waiting | error | offline
  current_task text,
  last_active_at timestamptz,
  raw jsonb,
  updated_at timestamptz default now()
);

create table if not exists events (
  id bigserial primary key,
  ts timestamptz default now(),
  agent_id text,
  kind text,                           -- message | run | cron | health | approval | system
  summary text,
  payload jsonb
);
create index if not exists events_ts on events (ts desc);
create index if not exists events_agent on events (agent_id, ts desc);

create table if not exists tasks (
  id text primary key,                 -- run id or job run id
  agent_id text,
  source text,                         -- cron | chat | webhook
  name text,
  status text,                         -- running | ok | error
  started_at timestamptz,
  finished_at timestamptz,
  output text,
  error text,
  model text,
  raw jsonb
);
create index if not exists tasks_agent on tasks (agent_id, started_at desc);

create table if not exists approvals (
  id bigserial primary key,
  ts timestamptz default now(),
  agent_id text,
  session_key text,
  action text,
  why text,
  draft text,
  risk text,
  status text default 'pending',       -- pending | approved | rejected | edited
  decision_note text,
  decided_at timestamptz,
  raw text
);
create index if not exists approvals_status on approvals (status, ts desc);

create table if not exists actions (
  id bigserial primary key,
  ts timestamptz default now(),
  kind text,                           -- message | approve | reject
  agent_id text,
  approval_id bigint,
  text text,
  status text default 'pending',       -- pending | sent | failed
  result jsonb,
  processed_at timestamptz
);
create index if not exists actions_pending on actions (status, ts);

create table if not exists raw_events (
  id bigserial primary key,
  ts timestamptz default now(),
  event text,
  payload jsonb
);

alter table instance   enable row level security;
alter table agents     enable row level security;
alter table events     enable row level security;
alter table tasks      enable row level security;
alter table approvals  enable row level security;
alter table actions    enable row level security;
alter table raw_events enable row level security;
