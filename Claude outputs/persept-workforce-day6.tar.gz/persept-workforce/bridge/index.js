// Persept workforce bridge v0
// Sits next to the OpenClaw gateway (same network namespace), speaks its WebSocket protocol
// as a trusted backend operator client, and mirrors what happens into Supabase:
//   agents   <- agents.list + session activity
//   events   <- session.message / cron / health events (human-readable rows)
//   tasks    <- cron runs (started / finished) + automation webhook payloads
//   approvals<- "APPROVAL REQUEST" blocks parsed from agent messages
//   raw_events <- everything, for the first days, so the mapping can be tuned
// Actions flow the other way: rows in `actions` (message / approve / reject) become chat.send
// calls into the agent's main session.
//
// Env: GATEWAY_URL (default ws://127.0.0.1:18789), OPENCLAW_GATEWAY_TOKEN, SUPABASE_URL,
//      SUPABASE_SERVICE_KEY, CLIENT_ID (default persept), CLIENT_NAME, RAW_EVENTS (1|0),
//      WEBHOOK_PORT (default 8787), ACTION_POLL_MS (default 5000)

import WebSocket from "ws";
import http from "node:http";
import { randomUUID } from "node:crypto";

const env = (k, d) => process.env[k] ?? d;
const GATEWAY_URL = env("GATEWAY_URL", "ws://127.0.0.1:18789");
const TOKEN = env("OPENCLAW_GATEWAY_TOKEN");
const SUPABASE_URL = env("SUPABASE_URL");
const SUPABASE_KEY = env("SUPABASE_SERVICE_KEY");
const CLIENT_ID = env("CLIENT_ID", "persept");
const CLIENT_NAME = env("CLIENT_NAME", CLIENT_ID);
const RAW = env("RAW_EVENTS", "1") === "1";
const WEBHOOK_PORT = Number(env("WEBHOOK_PORT", "8787"));
const ACTION_POLL_MS = Number(env("ACTION_POLL_MS", "5000"));

if (!TOKEN || !SUPABASE_URL || !SUPABASE_KEY) {
  console.error("bridge: OPENCLAW_GATEWAY_TOKEN, SUPABASE_URL and SUPABASE_SERVICE_KEY are required");
  process.exit(1);
}
const log = (...a) => console.log(new Date().toISOString(), "bridge:", ...a);

// ---------- Supabase (PostgREST) ----------
async function sb(path, { method = "GET", body, prefer } = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method,
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      ...(prefer ? { Prefer: prefer } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`supabase ${method} ${path}: ${r.status} ${await r.text()}`);
  const t = await r.text();
  return t ? JSON.parse(t) : null;
}
const upsert = (table, rows) => sb(table, { method: "POST", body: rows, prefer: "resolution=merge-duplicates,return=minimal" });
const insert = (table, rows) => sb(table, { method: "POST", body: rows, prefer: "return=minimal" });
const patch = (table, filter, body) => sb(`${table}?${filter}`, { method: "PATCH", body, prefer: "return=minimal" });
const safe = (p, what) => p.catch((e) => log(`${what} failed:`, e.message));

// ---------- helpers ----------
const agentFromSessionKey = (k) => (typeof k === "string" && k.startsWith("agent:") ? k.split(":")[1] : null);
const mainSessionKey = (agentId) => `agent:${agentId}:main`;
const trunc = (s, n = 200) => (typeof s === "string" && s.length > n ? s.slice(0, n) + "…" : s);

// "APPROVAL REQUEST" block parser (format defined in agents/_shared/GUARDRAILS.md).
// A message may carry several blocks (Hunter's daily run does); each becomes one approval row.
function parseApprovals(text) {
  if (typeof text !== "string" || !/APPROVAL REQUEST/i.test(text)) return [];
  const parts = text.split(/(?=APPROVAL REQUEST\b)/i).filter((p) => /^APPROVAL REQUEST/i.test(p.trim()));
  return parts.map((block) => {
    block = block.trim();
    const field = (name) => {
      const m = block.match(new RegExp(`^${name}:\\s*([\\s\\S]*?)(?=^(?:agent|action|why|draft|risk):|(?![\\s\\S]))`, "mi"));
      return m ? m[1].trim() : null;
    };
    // risk is last; strip any trailing prose after its first paragraph
    let risk = field("risk");
    if (risk) risk = risk.split(/\n\s*\n/)[0].trim();
    return { agent: field("agent"), action: field("action"), why: field("why"), draft: field("draft"), risk, raw: block };
  }).filter((a) => a.action || a.draft);
}
const parseApproval = (t) => parseApprovals(t)[0] ?? null;

// ---------- Gateway client ----------
let ws = null;
let connected = false;
const pending = new Map(); // id -> {resolve, reject}
let backoff = 1000;
const knownAgents = new Set();

function rpc(method, params = {}) {
  return new Promise((resolve, reject) => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return reject(new Error("not connected"));
    const id = randomUUID();
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ type: "req", id, method, params }));
    setTimeout(() => { if (pending.delete(id)) reject(new Error(`timeout ${method}`)); }, 30000);
  });
}

function connect() {
  log("connecting", GATEWAY_URL);
  ws = new WebSocket(GATEWAY_URL);
  ws.on("open", () => {
    // Trusted backend client on loopback: no device signature needed (see docs: handshake).
    const id = randomUUID();
    pending.set(id, {
      resolve: (payload) => onHello(payload),
      reject: (e) => { log("handshake rejected:", e.message); ws.close(); },
    });
    ws.send(JSON.stringify({
      type: "req", id, method: "connect",
      params: {
        minProtocol: 4, maxProtocol: 4,
        client: { id: "gateway-client", displayName: "persept-bridge", version: "0.1.0", platform: "linux", mode: "backend" },
        role: "operator",
        scopes: ["operator.read", "operator.write", "operator.approvals"],
        caps: [], commands: [], permissions: {},
        auth: { token: TOKEN },
        locale: "en-US", userAgent: "persept-bridge/0.1.0",
      },
    }));
  });
  ws.on("message", (buf) => {
    let f; try { f = JSON.parse(buf.toString()); } catch { return; }
    if (f.type === "res") {
      const p = pending.get(f.id); if (!p) return; pending.delete(f.id);
      f.ok ? p.resolve(f.payload) : p.reject(new Error(f.error?.message || JSON.stringify(f.error)));
    } else if (f.type === "event") {
      onEvent(f.event, f.payload, f).catch((e) => log("event handler failed:", e.message));
    }
  });
  ws.on("close", () => { connected = false; log("disconnected; retry in", backoff); setTimeout(connect, backoff); backoff = Math.min(backoff * 2, 60000); });
  ws.on("error", (e) => log("ws error:", e.message));
}

async function onHello(payload) {
  connected = true; backoff = 1000;
  log("connected; protocol", payload?.protocol, "server", payload?.server?.version);
  await safe(upsert("instance", [{ id: CLIENT_ID, name: CLIENT_NAME, gateway_version: payload?.server?.version ?? null, last_seen_at: new Date().toISOString() }]), "instance upsert");
  if (RAW) await safe(insert("raw_events", [{ event: "hello-ok", payload: { features: payload?.features, auth: payload?.auth } }]), "raw hello");
  await syncAgents();
  await subscribeSessions();
  historySeeded = false;
  await syncAllHistory();
}

async function syncAgents() {
  try {
    const res = await rpc("agents.list", {});
    const list = res?.agents ?? res?.list ?? (Array.isArray(res) ? res : []);
    const rows = list.map((a) => ({
      id: a.id ?? a.agentId,
      name: a.identity?.name ?? a.name ?? a.id,
      emoji: a.identity?.emoji ?? null,
      model: a.model ?? a.runtime?.model ?? null,
      raw: a,
      updated_at: new Date().toISOString(),
    })).filter((r) => r.id);
    if (rows.length) await upsert("agents", rows);
    for (const r of rows) knownAgents.add(r.id);
    log("agents synced:", rows.map((r) => r.id).join(", "));
  } catch (e) { log("agents.list failed:", e.message); }
}

async function subscribeSessions() {
  try {
    await rpc("sessions.subscribe", {}).catch((e) => log("sessions.subscribe failed:", e.message));
    const res = await rpc("sessions.list", { limit: 60 });
    const list = res?.sessions ?? res?.items ?? res?.list ?? (Array.isArray(res) ? res : []);
    if (Array.isArray(list)) { await applySessionActivity(list); log("sessions listed:", list.length); }
    else log("sessions.list returned unexpected shape:", JSON.stringify(res).slice(0, 200));
  } catch (e) { log("sessions.list failed:", e.message); }
}

async function applySessionActivity(sessions) {
  const byAgent = new Map();
  for (const s of sessions) {
    const agentId = s.agentId ?? agentFromSessionKey(s.sessionKey);
    if (!agentId) continue;
    const cur = byAgent.get(agentId) ?? { working: false, last: null };
    if (s.hasActiveRun || (Array.isArray(s.activeRunIds) && s.activeRunIds.length)) cur.working = true;
    const t = s.lastActivityAt ?? s.updatedAt;
    if (t && (!cur.last || t > cur.last)) cur.last = t;
    byAgent.set(agentId, cur);
  }
  for (const [id, v] of byAgent) {
    await safe(patch("agents", `id=eq.${encodeURIComponent(id)}`, {
      status: v.working ? "working" : "idle",
      ...(v.last ? { last_active_at: new Date(typeof v.last === "number" ? v.last : v.last).toISOString() } : {}),
      updated_at: new Date().toISOString(),
    }), `agent ${id} status`);
  }
}

// ---------- Events ----------
async function onEvent(name, payload, frame) {
  if (RAW && name !== "tick") await safe(insert("raw_events", [{ event: name, payload: payload ?? frame }]), "raw event");
  switch (name) {
    case "sessions.changed": {
      const list = payload?.sessions ?? payload?.list ?? [];
      if (Array.isArray(list) && list.length) await applySessionActivity(list);
      else await subscribeSessions();
      break;
    }
    case "session.message": {
      const sessionKey = payload?.sessionKey ?? payload?.session?.sessionKey;
      const agentId = payload?.agentId ?? agentFromSessionKey(sessionKey);
      if (agentId) setTimeout(() => syncHistory(agentId).catch(() => {}), 1500);
      break;
    }
    case "session.observer": {
      const agentId = payload?.agentId ?? agentFromSessionKey(payload?.sessionKey);
      const headline = payload?.headline ?? payload?.status ?? payload?.digest;
      if (agentId && typeof headline === "string") await safe(patch("agents", `id=eq.${encodeURIComponent(agentId)}`, { current_task: trunc(headline, 140), updated_at: new Date().toISOString() }), "observer");
      break;
    }
    case "cron": {
      const job = payload?.job ?? payload; const run = payload?.run ?? payload;
      const agentId = job?.agentId ?? run?.agentId ?? payload?.agentId;
      const status = run?.status ?? payload?.status ?? payload?.action;
      const runId = run?.runId ?? payload?.runId;
      const name = job?.name ?? payload?.jobName ?? payload?.name;
      await safe(insert("events", [{ agent_id: agentId, kind: "cron", summary: `${name ?? "job"} ${status ?? ""}`.trim(), payload }]), "event cron");
      if (runId) await safe(upsert("tasks", [{
        id: String(runId), agent_id: agentId, source: "cron", name,
        status: status === "error" ? "error" : status === "ok" || status === "finished" ? "ok" : "running",
        started_at: run?.runAtIso ?? run?.runAtMs ? new Date(run.runAtIso ?? run.runAtMs).toISOString() : new Date().toISOString(),
        finished_at: status === "ok" || status === "error" || status === "finished" ? new Date().toISOString() : null,
        error: run?.error ?? null, model: run?.model ?? null, raw: payload,
      }]), "task cron");
      if (agentId) await safe(patch("agents", `id=eq.${encodeURIComponent(agentId)}`, { status: status === "error" ? "error" : status === "started" ? "working" : "idle", updated_at: new Date().toISOString() }), "agent cron status");
      break;
    }
    case "health": {
      await safe(upsert("instance", [{ id: CLIENT_ID, health: payload, last_seen_at: new Date().toISOString(), updated_at: new Date().toISOString() }]), "instance health");
      break;
    }
    case "session.approval": case "exec.approval.requested": case "exec.approval.resolved": {
      await safe(insert("events", [{ agent_id: payload?.agentId ?? agentFromSessionKey(payload?.sessionKey), kind: "approval", summary: `${name}: ${trunc(JSON.stringify(payload), 160)}`, payload }]), "event approval");
      break;
    }
    case "agents.changed": case "config.changed": await syncAgents(); break;
    default: break;
  }
}

// ---------- Message history (source of truth for the chat views) ----------
// chat.history has a documented shape (messageId, role, text, timestamp), unlike the
// session.message event payload on this version. Poll it per agent and insert what is new.
const seenMsg = new Map(); // agentId -> Set(messageId)
let historySeeded = false;

async function syncHistory(agentId) {
  if (!connected) return;
  const sessionKey = mainSessionKey(agentId);
  let res;
  try { res = await rpc("chat.history", { sessionKey, limit: 60 }); }
  catch (e) { if (!/not found|unknown session/i.test(e.message)) log("chat.history failed:", agentId, e.message); return; }
  const msgs = res?.messages ?? [];
  if (!Array.isArray(msgs)) return;
  const seen = seenMsg.get(agentId) ?? new Set();
  const fresh = [];
  for (const m of msgs) {
    const id = m.messageId ?? m.id ?? `${m.timestamp}-${m.role}`;
    if (seen.has(id)) continue;
    seen.add(id);
    if (historySeeded) fresh.push({ id, m });
  }
  seenMsg.set(agentId, seen);
  for (const { id, m } of fresh) {
    const c = m.content ?? m.message?.content ?? m.parts;
    const text = typeof m.text === "string" ? m.text
      : typeof c === "string" ? c
      : Array.isArray(c) ? c.map((x) => (typeof x === "string" ? x : x?.text ?? "")).join("")
      : typeof m.message?.text === "string" ? m.message.text : "";
    const role = m.role ?? m.message?.role ?? (m.sender ?? m.author);
    if (!text.trim() || (role !== "user" && role !== "assistant")) {
      log(`history ${agentId}: skipped role=${role} keys=${Object.keys(m).join(",")} text=${JSON.stringify(String(text).slice(0, 60))}`);
      continue;
    }
    m.role = role;
    const ts = m.timestamp ? new Date(m.timestamp).toISOString() : new Date().toISOString();
    await safe(insert("events", [{ ts, agent_id: agentId, kind: "message", summary: `${m.role}: ${trunc(text, 160)}`, payload: { sessionKey, role: m.role, text, messageId: id } }]), "history insert");
    if (m.role === "assistant") {
      const aps = parseApprovals(text);
      if (aps.length) await safe(insert("approvals", aps.map((ap) => ({ agent_id: ap.agent ?? agentId, session_key: sessionKey, action: ap.action, why: ap.why, draft: ap.draft, risk: ap.risk, raw: ap.raw }))), "approval insert");
      await safe(patch("agents", `id=eq.${encodeURIComponent(agentId)}`, { last_active_at: ts, status: "idle", updated_at: new Date().toISOString() }), "agent active");
    }
  }
  if (fresh.length) log(`history ${agentId}: +${fresh.length}`);
}

async function syncAllHistory() {
  for (const id of knownAgents) await syncHistory(id);
  if (!historySeeded) { historySeeded = true; log("history seeded for", [...knownAgents].join(", ")); }
}
setInterval(() => syncAllHistory().catch((e) => log("syncAllHistory:", e.message)), 15000);

// ---------- Actions (dashboard -> agents) ----------
async function pollActions() {
  if (!connected) return;
  let rows = [];
  try { rows = await sb("actions?status=eq.pending&order=ts.asc&limit=10"); } catch (e) { log("actions poll failed:", e.message); return; }
  for (const a of rows) {
    try {
      let text = a.text ?? "";
      if (a.kind === "approve" || a.kind === "reject") {
        text = `APPROVAL DECISION for request #${a.approval_id}: ${a.kind === "approve" ? "APPROVED" : "REJECTED"}${a.text ? ". Note from owner: " + a.text : ""}. ${a.kind === "approve" ? "Proceed with exactly the approved draft." : "Do not proceed."}`;
        await safe(patch("approvals", `id=eq.${a.approval_id}`, { status: a.kind === "approve" ? "approved" : "rejected", decision_note: a.text ?? null, decided_at: new Date().toISOString() }), "approval decision");
      }
      const res = await rpc("chat.send", { sessionKey: mainSessionKey(a.agent_id), agentId: a.agent_id, message: text, idempotencyKey: `action-${a.id}` });
      await patch("actions", `id=eq.${a.id}`, { status: "sent", result: res ?? {}, processed_at: new Date().toISOString() });
      for (const d of [4000, 10000, 20000]) setTimeout(() => syncHistory(a.agent_id).catch(() => {}), d);
    } catch (e) {
      log("action failed:", a.id, e.message);
      await safe(patch("actions", `id=eq.${a.id}`, { status: "failed", result: { error: e.message }, processed_at: new Date().toISOString() }), "action fail mark");
    }
  }
}
setInterval(() => pollActions().catch((e) => log("pollActions:", e.message)), ACTION_POLL_MS);
setInterval(() => { if (connected) syncAgents(); }, 10 * 60 * 1000);

// ---------- Webhook receiver (automations --webhook, later GitHub / forms) ----------
http.createServer(async (req, res) => {
  if (req.method !== "POST" || !req.url.startsWith("/hook")) { res.writeHead(404); return res.end(); }
  let body = ""; req.on("data", (c) => (body += c));
  req.on("end", async () => {
    let p = {}; try { p = JSON.parse(body || "{}"); } catch {}
    const source = new URL(req.url, "http://x").searchParams.get("source") ?? "webhook";
    if (RAW) await safe(insert("raw_events", [{ event: `webhook:${source}`, payload: p }]), "raw webhook");
    const agentId = p.agentId ?? p.job?.agentId ?? null;
    await safe(insert("events", [{ agent_id: agentId, kind: "run", summary: `${source}: ${trunc(p.summary ?? p.jobName ?? p.name ?? JSON.stringify(p), 160)}`, payload: p }]), "webhook event");
    if (p.runId) await safe(upsert("tasks", [{ id: String(p.runId), agent_id: agentId, source: "cron", name: p.jobName ?? p.name ?? null, status: p.status === "error" ? "error" : "ok", finished_at: new Date().toISOString(), output: typeof p.output === "string" ? p.output : (p.text ?? null), error: p.error ?? null, raw: p }]), "webhook task");
    res.writeHead(200, { "Content-Type": "application/json" }); res.end('{"ok":true}');
  });
}).listen(WEBHOOK_PORT, "127.0.0.1", () => log("webhook listening on 127.0.0.1:" + WEBHOOK_PORT));

connect();
