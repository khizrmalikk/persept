import type { Metadata } from "next";
import "./globals.css";
import { Nav } from "@/components/Nav";
import { AutoRefresh } from "@/components/AutoRefresh";

const NAME = process.env.NEXT_PUBLIC_CLIENT_NAME ?? "Workforce";
export const metadata: Metadata = { title: `${NAME} · workforce`, description: "AI workforce command centre" };
export const dynamic = "force-dynamic";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ink = process.env.NEXT_PUBLIC_BRAND_INK ?? "#21201B";
  const bg = process.env.NEXT_PUBLIC_BRAND_BG ?? "#F4F2EC";
  return (
    <html lang="en" style={{ ["--brand-ink" as string]: ink, ["--brand-bg" as string]: bg }}>
      <body>
        <div className="wrap">
          <Nav />
          {children}
        </div>
        <AutoRefresh seconds={6} />
      </body>
    </html>
  );
}
