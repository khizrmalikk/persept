import { db, type Agent, type Approval, type Event } from "@/lib/supabase";
import { AgentCard } from "@/components/AgentCard";
import { ago } from "@/lib/format";
import Link from "next/link";

export default async function Office() {
  const s = db();
  const since = new Date(); since.setHours(0, 0, 0, 0);
  const [{ data: agents }, { data: pending }, { data: recent }, { data: todays }] = await Promise.all([
    s.from("agents").select("*").order("id"),
    s.from("approvals").select("id, agent_id").eq("status", "pending"),
    s.from("events").select("*").order("ts", { ascending: false }).limit(8),
    s.from("events").select("agent_id").gte("ts", since.toISOString()).in("kind", ["run", "cron", "message"]),
  ]);
  const pendingBy = new Map<string, number>();
  (pending as Pick<Approval, "id" | "agent_id">[] | null)?.forEach((p) => pendingBy.set(p.agent_id ?? "", (pendingBy.get(p.agent_id ?? "") ?? 0) + 1));
  const todayBy = new Map<string, number>();
  (todays as { agent_id: string | null }[] | null)?.forEach((e) => todayBy.set(e.agent_id ?? "", (todayBy.get(e.agent_id ?? "") ?? 0) + 1));

  return (
    <>
      <p className="kicker">001 / office</p>
      <h1>the team<span className="cursor" /></h1>
      {!agents?.length ? <div className="empty">no agents yet. once the bridge is connected they appear here.</div> : (
        <div className="grid">
          {(agents as Agent[]).map((a) => <AgentCard key={a.id} a={a} pending={pendingBy.get(a.id) ?? 0} today={todayBy.get(a.id) ?? 0} />)}
        </div>
      )}
      <div style={{ height: 30 }} />
      <p className="kicker">002 / latest</p>
      <ul className="feed">
        {(recent as Event[] | null)?.map((e) => (
          <li key={e.id}><span className="t">{ago(e.ts)}</span><span className="who">{e.agent_id ?? "system"}</span><span><span className="kind">{e.kind}</span>{e.summary}</span></li>
        ))}
      </ul>
      <p style={{ marginTop: 12 }}><Link className="muted" href="/activity">full activity →</Link></p>
    </>
  );
}
