import { createClient } from "@supabase/supabase-js";

// Server-only client. Never import this from a client component.
export function db() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!url || !key) throw new Error("SUPABASE_URL and SUPABASE_SERVICE_KEY are required");
  return createClient(url, key, { auth: { persistSession: false } });
}

export type Agent = {
  id: string; name: string | null; role: string | null; emoji: string | null; model: string | null;
  status: string | null; current_task: string | null; last_active_at: string | null; updated_at: string | null;
};
export type Event = { id: number; ts: string; agent_id: string | null; kind: string | null; summary: string | null; payload: unknown };
export type Task = { id: string; agent_id: string | null; source: string | null; name: string | null; status: string | null; started_at: string | null; finished_at: string | null; error: string | null; model: string | null };
export type Approval = { id: number; ts: string; agent_id: string | null; action: string | null; why: string | null; draft: string | null; risk: string | null; status: string | null; decision_note: string | null; decided_at: string | null };
export type Instance = { id: string; name: string | null; gateway_version: string | null; health: unknown; last_seen_at: string | null };
