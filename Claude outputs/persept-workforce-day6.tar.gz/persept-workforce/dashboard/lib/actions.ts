"use server";

import { revalidatePath } from "next/cache";
import { db } from "./supabase";

// Every write from the dashboard is a row in `actions`; the bridge turns it into a gateway call.

export async function sendMessage(agentId: string, text: string) {
  if (!agentId || !text.trim()) return;
  await db().from("actions").insert({ kind: "message", agent_id: agentId, text: text.trim() });
  revalidatePath(`/agents/${agentId}`);
}

export async function decideFromForm(fd: FormData) {
  const id = Number(fd.get("id"));
  const agent = String(fd.get("agent") ?? "chief");
  const decision = String(fd.get("decision")) === "approve" ? "approve" : "reject";
  const note = String(fd.get("note") ?? "");
  if (!id) return;
  await decideApproval(id, agent, decision, note);
}

export async function sendMessageFromForm(fd: FormData) {
  await sendMessage(String(fd.get("agent") ?? ""), String(fd.get("text") ?? ""));
}

export async function decideApproval(approvalId: number, agentId: string, decision: "approve" | "reject", note?: string) {
  await db().from("actions").insert({ kind: decision, agent_id: agentId, approval_id: approvalId, text: note?.trim() || null });
  // Optimistic: mark it so it leaves the inbox immediately; the bridge sets the final state.
  await db().from("approvals").update({ status: decision === "approve" ? "approved" : "rejected", decision_note: note?.trim() || null, decided_at: new Date().toISOString() }).eq("id", approvalId);
  revalidatePath("/approvals");
  revalidatePath("/");
}
