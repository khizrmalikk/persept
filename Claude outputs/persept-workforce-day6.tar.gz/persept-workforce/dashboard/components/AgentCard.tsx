import Link from "next/link";
import type { Agent } from "@/lib/supabase";
import { ago, STATUS_LABEL } from "@/lib/format";

export function AgentCard({ a, pending, today }: { a: Agent; pending: number; today: number }) {
  const status = pending > 0 ? "waiting" : (a.status ?? "idle");
  return (
    <Link href={`/agents/${a.id}`} className="card">
      <div className="head">
        <span className="emoji">{a.emoji ?? "•"}</span>
        <div>
          <div className="name">{a.name ?? a.id}</div>
          <div className="role">{a.role ?? a.id}</div>
        </div>
      </div>
      <div className="statusline"><span className={`dot ${status}`} />{STATUS_LABEL[status] ?? status}{pending > 0 ? ` · ${pending} approval${pending > 1 ? "s" : ""}` : ""}</div>
      <div className="task">{a.current_task ?? (status === "idle" ? "nothing in progress" : "")}</div>
      <div className="meta"><span>active {ago(a.last_active_at)}</span><span>today {today}</span><span>{(a.model ?? "").replace("anthropic/", "")}</span></div>
    </Link>
  );
}
