import { db } from "@/lib/supabase";
import { ago } from "@/lib/format";
import { NavLinks } from "./NavLinks";

export async function Nav() {
  const NAME = process.env.NEXT_PUBLIC_CLIENT_NAME ?? "Workforce";
  const TAG = process.env.NEXT_PUBLIC_CLIENT_TAGLINE ?? "";
  let pending = 0; let seen: string | null = null;
  try {
    const s = db();
    const [{ count }, { data: inst }] = await Promise.all([
      s.from("approvals").select("id", { count: "exact", head: true }).eq("status", "pending"),
      s.from("instance").select("last_seen_at").limit(1).maybeSingle(),
    ]);
    pending = count ?? 0; seen = inst?.last_seen_at ?? null;
  } catch { /* nav still renders if the db is unreachable */ }
  return (
    <nav className="nav">
      <div className="brand">{NAME}<small>{TAG}</small></div>
      <NavLinks pending={pending} />
      <div className="status">bridge {seen ? `seen ${ago(seen)}` : "not seen"}</div>
    </nav>
  );
}
