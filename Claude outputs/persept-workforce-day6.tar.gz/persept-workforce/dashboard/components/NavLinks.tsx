"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

export function NavLinks({ pending }: { pending: number }) {
  const p = usePathname();
  const is = (h: string) => (h === "/" ? p === "/" : p.startsWith(h));
  return (
    <>
      <Link className={`link ${is("/") ? "active" : ""}`} href="/">office</Link>
      <Link className={`link ${is("/activity") ? "active" : ""}`} href="/activity">activity</Link>
      <Link className={`link ${is("/approvals") ? "active" : ""}`} href="/approvals">
        approvals{pending > 0 && <span className="badge">{pending}</span>}
      </Link>
    </>
  );
}
